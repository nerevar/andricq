<?php
/**
 * Класс, отвечающий за работу сервер ICQ
 */ 
class AndrICQ {

	/**
	 * Соединение клиента с сервером, инициализация
	 * @return 
	 */	
	static function connect() {
		return TRUE;
	}
	
	static function checkOnline() {
		$sql = "UPDATE users SET status = 'online' WHERE current_timestamp - last_connected < 300";
		mysql_query($sql);	
	
		$sql = "UPDATE users SET status = 'afk' WHERE current_timestamp - last_connected > 300";
		mysql_query($sql);
		
		$sql = "UPDATE users SET status = 'offline' WHERE current_timestamp - last_connected > 600";
		mysql_query($sql);
	}
	
	/**
	 * Авторизирует пользователя на сайте 
	 * @param object $login - логин
	 * @return 
	 */
	static function auth($login) {
		// TODO: проверка логина на разрешенные символы
		$login = mysql_real_escape_string($login);
		$sql = "SELECT * FROM users WHERE login = '{$login}'";
		$query = mysql_query($sql);
		if (mysql_num_rows($query) > 0) {
			// пользователь есть в бд
			self::update_users_online($login);
			return true;
		} else {
			// добавляем нового пользователя
			$sql = "INSERT INTO users (login) VALUES ('{$login}')";
			mysql_query($sql);
			return true;
		}
	}	
	
	/**
	 * Формирует ответ клиенту
	 * @param object $result - ответ
	 * @return 
	 */
	static function response($result, $info = NULL) {
		$data = array();
		
		$data['result'] = $result;

		if ($info) {
			$data['info'] = $info;
		}
		
		print json_encode($data);		
	}
	
	/**
	 * Логирует записи в бд о действиях клиентов
	 * @param object $action - действие
	 * @param object $info [optional] - дополнительная информация, результат
	 * @return 
	 */
	static function log($action, $info = '') {
		$info = $info ? mysql_real_escape_string($info) : '';
		$action = mysql_real_escape_string($action);
		$ip = $_SERVER['REMOTE_ADDR'];
		
		$request = mysql_real_escape_string(print_r($_REQUEST,1));
		$sql = "INSERT INTO logs (date, action, request, info, ip) 
				VALUES (NOW(), '{$action}','{$request}', '{$info}', '{$ip}')";
		mysql_query($sql);
	}
	
	static function update_users_online($login) {
		$login = mysql_real_escape_string($login);
		$sql = "UPDATE users SET last_connected = CURRENT_TIMESTAMP WHERE login = '{$login}'";
		mysql_query($sql);
	}
	
	static function get_users_list() {
		$users = array();

		$user = $_REQUEST['user'];
		$user_id = self::get_user_id($user);
		self::update_users_online($user);
		
		$where = '';
		if ($user_id) {
			$where .= " AND u.id != {$user_id}";
		}
		
		$sql = "SELECT u.*, 
					(SELECT COUNT(m.id) FROM messages m WHERE (m.user_from = u.id AND m.is_new = 1)) as unread
				FROM users u 
				WHERE u.status != 'offline' {$where}";
		$result = mysql_query($sql);
		
		while ($row = mysql_fetch_assoc($result)) {
			$users[] = array(
				'id' => $row['id'],
				'login' => $row['login'],
				'status' => $row['status'],
				'unread' => $row['unread'],
			);
			
		}
		
		return $users;
	}
	
	static function send_message() {
		$message = $_REQUEST['message'];
		$from = $_REQUEST['from'];
		$to = $_REQUEST['to'];
		
		self::update_users_online($from);

		$to_id = self::get_user_id($to);
		$from_id = self::get_user_id($from);
		if ($from_id && $to_id) {
			// отправляем сообщение
			$message = mysql_real_escape_string($message);
			$sql = "INSERT INTO messages (date_sent, user_from, user_to, message) 
					VALUES(NOW(), {$from_id}, {$to_id}, '{$message}')";
			mysql_query($sql);
			
			if (mysql_insert_id()) {
				return TRUE;
			} else {
				return FALSE;
			}
		} else {
			// ошибка, ненайден отправитель или получатель
			return FALSE;
		}
	}
	
	static function get_user_id($login = '') {
		$login = mysql_real_escape_string($login);
		
		$sql = "SELECT id FROM users WHERE login = '{$login}'";
		$result = mysql_query($sql);
		if ($row = mysql_fetch_assoc($result)) {
			return $row['id'];
		}	
		return NULL;
	}
	
	static function get_messages() {
		$user = $_REQUEST['user'];
		$buddy = $_REQUEST['buddy'];
		
		self::update_users_online($user);
		
		$user_id = self::get_user_id($user);
		$buddy_id = self::get_user_id($buddy);
		
		if ($user_id && $buddy_id) {
			// получаем сообщения
			$messages = array();
			$sql = "SELECT m.*, UNIX_TIMESTAMP(m.date_sent) as date_timestamp, DATE_FORMAT(m.date_sent, '%e.%m.%Y %H:%i') as date_str,
						u1.login as username_from, u2.login as username_to
					FROM messages m 
					INNER JOIN users u1 ON (m.user_from = u1.id)
					INNER JOIN users u2 ON (m.user_to = u2.id)
					WHERE (m.user_to = {$user_id} AND m.user_from = {$buddy_id}) OR
						  (m.user_to = {$buddy_id} AND m.user_from = {$user_id})
					ORDER BY m.id ASC";
			$result = mysql_query($sql);
			while ($row = mysql_fetch_assoc($result)) {
				
				// убираем статус непрочтённое
				if ($row['username_to'] == $user) {
					$sql = "UPDATE messages SET is_new = 0 WHERE id = " . $row['id'];
					mysql_query($sql);
				}
				
				$messages[] = array(
					'date_str' => $row['date_str'],
					'from' => $row['username_from'],
					'to' => $row['username_to'],
					'message' => $row['message'],
				);
			}
			return $messages;
		} else {
			return NULL;
		}
	}
	
	// получает количество сообщений
	static function check_new_messages() {
		$user = $_REQUEST['user'];
		$buddy = $_REQUEST['buddy'];
		
		self::update_users_online($user);
		
		$user_id = self::get_user_id($user);
		$buddy_id = self::get_user_id($buddy);
		
		if ($user_id && $buddy_id) {
			// получаем количество
			$messages = array();
			$sql = "SELECT COUNT(m.id) as unread
					FROM messages m 
					INNER JOIN users u1 ON (m.user_from = u1.id)
					INNER JOIN users u2 ON (m.user_to = u2.id)
					WHERE m.is_new = 1 AND 
						((m.user_to = {$user_id} AND m.user_from = {$buddy_id}) OR
						 (m.user_to = {$buddy_id} AND m.user_from = {$user_id}))";
			$result = mysql_query($sql);
			$unread = 0;
			if ($row = mysql_fetch_assoc($result)) {
				$unread = intval($row['unread']);
			}
			return $unread;
		} else {
			return 0;
		}		
	}
	
}