<?
	$db['host'] = '127.0.0.1';
	$db['user'] = 'root';
	$db['pass'] = '';
	$db['db'] = 'andricq';
	
	mysql_connect($db['host'],$db['user'],$db['pass']);
	mysql_select_db($db['db']);
	
