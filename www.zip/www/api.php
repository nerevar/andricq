<?
	require_once("sys.php");
	require_once("AndrICQ.php");
	AndrICQ::checkOnline();
	
	if ($_REQUEST) {
		switch ($_REQUEST['type']) {
			case 'connect':
				if (AndrICQ::connect()) {
					AndrICQ::response('ok');
					AndrICQ::log('connect','success');
				} else {
					AndrICQ::response('error');
					AndrICQ::log('connect','error');
				}
				break;
			case 'auth':
				$login = $_REQUEST['login'];
				if (AndrICQ::auth($login)) {
					AndrICQ::response('ok');
					AndrICQ::log('auth','success');
				} else {
					AndrICQ::response('error');
					AndrICQ::log('auth','error');
				}
				break;
			case 'get_users_list':
				$list = AndrICQ::get_users_list();
				AndrICQ::response('ok', $list);
				AndrICQ::log('get_users_list',print_r($list,1));
				break;
			case 'send_message':
				if (AndrICQ::send_message()) {
					AndrICQ::response('ok');
					AndrICQ::log('send_message', 'success');
				} else {
					AndrICQ::response('error');
					AndrICQ::log('send_message', 'error');				
				}
				break;
			case 'load_messages':
					$list = AndrICQ::get_messages();
					AndrICQ::response('ok', $list);
					AndrICQ::log('load_messages', print_r($list,1));
				break;
			case 'check_new_messages':
					$unread = AndrICQ::check_new_messages();
					$data = array (
						'unread' => $unread,
					);
					AndrICQ::response('ok', $data);
					AndrICQ::log('check_new_messages', print_r($unread,1));
				break;				
			default:
				AndrICQ::log('default_action');
				break;
		}
	} else {
		AndrICQ::log('hz');
	}